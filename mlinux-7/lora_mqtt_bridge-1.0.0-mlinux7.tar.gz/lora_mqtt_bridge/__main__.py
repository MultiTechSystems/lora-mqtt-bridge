"""Allow running the package with python -m lora_mqtt_bridge."""

from lora_mqtt_bridge.main import main

if __name__ == "__main__":
    raise SystemExit(main())
